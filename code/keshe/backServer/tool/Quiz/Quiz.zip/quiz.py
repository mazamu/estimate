import csv
import random
class quiz():
    def __init__(self):
        ## 雅思词汇答对个数
        self.ieltsCounter = 0
        ## 四六级词汇答对个数
        self.cetCounter = 0
        ## 考研词汇答对个数
        self.bstsCounter = 0

        ## 雅思权重
        self.weightIelts = 0.3
        ## 四六级权重
        self.weightcet = 0.4
        ## 考研权重
        self.weightBsts = 0.3

        ## 出题
        self.problemNum = 100
        self.problem = [{'word':None,'flag':False} for i in range(self.problemNum)]


    ## 读取每个词库的csv文件
    def GetWordcsv(self):
        # 读取雅思词汇
        wordList1 = []
        with open("./ielts.csv", "r") as csvfile1:
            reader = csv.reader(csvfile1)
            for line in reader:
                wordList1 = wordList1 + line

        # 读取四六级词汇
        wordList2 = []
        with open("./cet.csv", "r") as csvfile2:
            reader = csv.reader(csvfile2)
            for line in reader:
                wordList2 = wordList2 + line

        # 读取考研词汇
        wordList3 = []
        with open("./ielts.csv", "r") as csvfile3:
            reader = csv.reader(csvfile3)
            for line in reader:
                wordList3 = wordList3 + line

        return wordList1,wordList2,wordList3

    def Problem(self, wordList1, wordList2, wordList3):
        problemList = []
        ielts = random.sample(wordList1, self.weightIelts)
        problemList = problemList + ielts

        cets = random.sample(wordList2, self.weightcet)
        problemList = problemList + cets

        bsts = random.sample(wordList3, self.weightBsts)
        problemList = problemList + bsts
        random.shuffle(problemList)

        ## 构成问题字典
        for i in range(self.problemNum):
            self.problem[i]['word'] = problemList[i]

        return self.problem



        return
    def getRightCount(self):
        rightCount = 0
        return rightCount

    def getEvaluationCount(self):
        return

    def answer(self,word,answer):
        for i in range(100):
            if True:
                return True

        return False